package com.amva.demorestapi.service;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.amva.demorestapi.entity.Course;

@Service
public class CourseServiceimpl implements CourseService {

	List<Course> list;

	public CourseServiceimpl() {
		list = new ArrayList<>();
		list.add(new Course(145, "Java Course", "Contains Basic of Java"));
		list.add(new Course(205, "Spring Boot", "Contains Rest Api"));
	}

	@Override
	public List<Course> getCourses() {
		return list;
	}

	@Override
	public Course getCourse(Long courseID) {
		Course c= null;
		for(Course course:list) {
			if(course.getId()==courseID)
			{
				c=course;
				break;
			}
		}
			
		return c;
	}

	@Override
	public Course addCourse(Course course) {


		list.add(course);
		return course;
	}

	@Override
	public Course updateCourse(Course course) {
		Course c=new Course();
		if(c.getId()==course.getId()) {			
			c.setTitle(course.getTitle());
			c.setDescription(course.getDescription());
		}
		
		return course;
	}
	
	

	@Override
	public void deleteCourse(long parseLong) {
		list = this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
	}

	@Override
	public Course patchCourse(Course course) {
		Course c=new Course();
		System.out.println("Get Id: "+course.getId());
		System.out.println("Get Description: "+course.getDescription());

		if(c.getId()==course.getId() || c.getDescription().equals(course.getDescription())){
		{
		   
			c.setDescription(course.getDescription());
		}
		
		if(c.getId()==course.getId() || c.getTitle().equals(course.getTitle()))
		{
		
			c.setTitle(course.getTitle());
		}
		
		
	}
		return c;

}
}
