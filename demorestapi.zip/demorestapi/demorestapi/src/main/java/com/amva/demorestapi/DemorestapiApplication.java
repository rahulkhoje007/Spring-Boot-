package com.amva.demorestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemorestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemorestapiApplication.class, args);
	}

}
